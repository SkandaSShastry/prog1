# prog1-2023-shell
This repo branch contains the shell for program 1 from cg class 2023 at nc state (ray tracing ellipsoids).
